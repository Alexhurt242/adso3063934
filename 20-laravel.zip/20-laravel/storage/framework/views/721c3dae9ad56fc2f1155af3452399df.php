
<h1>Dashboard</h1>
<h2><?php echo e(Auth::user()->fullname); ?></h2>
<h3>You're Logged in!</h3>
<form method="post" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <a href="javascript:;"
            onclick="event.preventDefault();
                    this.closest('form').submit();">
                        Log Out
    </a>
</form><?php /**PATH C:\Users\APRENDIZ\Desktop\adso3063934\20-laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>