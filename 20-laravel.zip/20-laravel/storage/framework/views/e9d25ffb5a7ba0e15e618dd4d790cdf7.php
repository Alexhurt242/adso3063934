<?php $__env->startSection('title', 'Register: Larapets 🐶'); ?>
<?php $__env->startSection('content'); ?>

    <section class="bg-[#0004] text-white rounded-lg md:w-[640px] w-[360px] p-8 flex flex-col gap-4 items-center justify-center">
        <h1 class="flex gap-4 justify-center items-center text-4xl">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#fff" viewBox="0 0 256 256"><path d="M256,136a8,8,0,0,1-8,8H232v16a8,8,0,0,1-16,0V144H200a8,8,0,0,1,0-16h16V112a8,8,0,0,1,16,0v16h16A8,8,0,0,1,256,136Zm-57.87,58.85a8,8,0,0,1-12.26,10.3C165.75,181.19,138.09,168,108,168s-57.75,13.19-77.87,37.15a8,8,0,0,1-12.25-10.3c14.94-17.78,33.52-30.41,54.17-37.17a68,68,0,1,1,71.9,0C164.6,164.44,183.18,177.07,198.13,194.85ZM108,152a52,52,0,1,0-52-52A52.06,52.06,0,0,0,108,152Z">                
            </path>
            </svg>
            Register
        </h1>
            <div class="card w-full ">
                <form method="POST" action="<?php echo e(route('register')); ?>" class="flex flex-col gap-4 card-body">
                    <?php echo csrf_field(); ?>
                    
                    <!-- Dos columnas -->
                    <div class="flex flex-col md:flex-row gap-4">
                        <div class="w-full md:w-1/2">
                            
                            <label class="label">Document</label>
                            <input type="text" class="input bg-[#0006] w-full mt-1 outline-0" name="document" placeholder="753921345" value="<?php echo e(old('document')); ?>"/>
                            <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="badge badge-error w-full mt-1 py-4"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            
                            <label class="label">FullName</label>
                            <input type="text" class="input bg-[#0006] w-full mt-1 outline-0" name="fullname" placeholder="John Doe" value="<?php echo e(old('fullname')); ?>"/>
                            <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="badge badge-error w-full mt-1 py-4"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            
                            <label class="label">Gender</label>
                            <select name="gender" class="select bg-[#0009] w-full outline-0">
                                <option value="">Select...</option>
                                <option value="male" <?php if(old('gender') == 'male'): ?> selected <?php endif; ?>>Male</option>
                                <option value="female" <?php if(old('gender') == 'female'): ?> selected <?php endif; ?>>Female</option>
                            </select>
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="badge badge-error w-full mt-1 py-4"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            
                            <label class="label">Birthdate</label>
                            <input type="date" class="input bg-[#0006] w-full mt-1 outline-0" name="birthdate" placeholder="1999-10-29" value="<?php echo e(old('birthdate')); ?>"/>
                            <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="badge badge-error w-full mt-1 py-4"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="w-full md:w-1/2">
                            
                            <label class="label">Phone</label>
                            <input type="text" class="input bg-[#0006] w-full mt-1 outline-0" name="phone" placeholder="123-456-7890" value="<?php echo e(old('phone')); ?>"/>
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="badge badge-error w-full mt-1 py-4"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            
                            <label class="label">Email</label>
                            <input type="text" name="email" class="input bg-[#0006] w-full outline-0" required placeholder="Email" value="<?php echo e(old('email')); ?>" />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="badge badge-error w-full mt-1 py-4"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            
                            <label class="label">Password</label>
                            <input type="password" class="input bg-[#0006] w-full outline-0" name="password" placeholder="Password" />
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="badge badge-error w-full mt-1 py-4"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            
                            <label class="label">Confirm Password</label>
                            <input type="password" class="input bg-[#0006] w-full outline-0" name="password_confirmation" placeholder="Password" />
                        </div>
                    </div>

                    <!-- Botón debajo de las dos columnas -->
                    <button class="btn btn-outline hover:bg-[#fff6] hover:text-white mt-4">Register</button>

                    <p class="text-sm text-center">
                        <a class="link link-default" href="<?php echo e(route('login')); ?>">
                           Already have an account? Login 
                        </a>
                    </p>
                    
                </form>
            </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\APRENDIZ\Desktop\adso3063934\20-laravel\resources\views/auth/register.blade.php ENDPATH**/ ?>